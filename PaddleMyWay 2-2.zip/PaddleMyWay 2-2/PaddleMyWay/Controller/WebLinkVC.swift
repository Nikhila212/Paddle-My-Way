//
//  WebLinkVC.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 21/02/2023.
//

import UIKit
import WebKit

class WebLinkVC: UIViewController {

    @IBOutlet var webView: WKWebView!
    @IBOutlet var spinnerView: UIActivityIndicatorView!
    
    var str = ""
    var url_str = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        webView.navigationDelegate = self
        let url = URL(string: url_str)!
        webView.load(URLRequest(url: url))
        webView.allowsBackForwardNavigationGestures = true
        spinnerView.isHidden = false
        
        self.navigationController?.navigationBar.isHidden = false
        self.navigationItem.title = str
    }
}

extension WebLinkVC: WKNavigationDelegate, WKUIDelegate{
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        
        spinnerView.isHidden = false
        spinnerView.startAnimating()
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        spinnerView.isHidden = true
        spinnerView.stopAnimating()
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        spinnerView.isHidden = true
        spinnerView.stopAnimating()
    }
}
