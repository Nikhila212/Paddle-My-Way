//
//  ProfileVC.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 20/02/2023.
//

import UIKit
import FirebaseAuth
import SDWebImage

class ProfileVC: UIViewController {
    
    @IBOutlet var nameView: UIView!
    @IBOutlet var emailView: UIView!
    @IBOutlet var passView: UIView!
    
    @IBOutlet var imgView: UIImageView!
    @IBOutlet var editView: UIView!
    @IBOutlet var nameLbl: UILabel!
    @IBOutlet var emailLbl: UILabel!
    
    var selectedImage: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Profile"
        self.setDesign()
        self.setUserData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.isHidden = false
    }
    
    func setUserData() -> Void {
        
        nameLbl.text = Auth.auth().currentUser?.displayName ?? ""
        emailLbl.text = Auth.auth().currentUser?.email ?? ""
        
        let url = Auth.auth().currentUser?.photoURL
        imgView.sd_setImage(with: url, placeholderImage: UIImage(named: "placeholder"),options: SDWebImageOptions(rawValue: 0), completed: { (image, error, cacheType, imageURL) in
        })
    }
    
    func setDesign() -> Void {
        
        imgView.layer.cornerRadius = imgView.frame.size.height * 0.5
        imgView.clipsToBounds = true
        
        editView.layer.cornerRadius = editView.frame.size.height * 0.5
        editView.clipsToBounds = true
        
        nameView.layer.cornerRadius = 8
        emailView.layer.cornerRadius = 8
        passView.layer.cornerRadius = 8
    }
    
    @IBAction func editProfileBtnClicked(_ sender: Any) {
        
        self.selectImage()
    }
    
    func selectImage() -> Void {
        
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { action in
            self.selectImageFromGallery()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { action in
            self.takeImageFromCamera()
        }))
        
        self.present(actionSheet, animated: true)
    }
    
    func selectImageFromGallery() {
        let pickerController = UIImagePickerController()
        
        pickerController.delegate = self
        pickerController.allowsEditing = true
        
        self.present(pickerController, animated: true)
    }
    
    func takeImageFromCamera() {
        let imagePicker = UIImagePickerController()
        
        imagePicker.allowsEditing = true
        imagePicker.delegate = self
        
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
        }
        self.present(imagePicker, animated: true)
    }
    
    func uploadProfileImage() -> Void {
        
        self.showSpinner(onView: self.view)
        var imageData:Data = selectedImage!.pngData()! as Data
        if imageData.count <= 0 {
            
            imageData = selectedImage!.jpegData(compressionQuality: 1.0)! as Data
        }
        
        let id = Auth.auth().currentUser?.uid ?? ""
        let name = "\(id).png"
        
        //        let obj = FirebaseStorageManager()
        //        obj.uploadImageData(data: imageData, directoryName: "uploads/", serverFileName: name) { (isSuccess, url) in
        //
        //            let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
        //
        //            let fileUrl = URL(string: url ?? "")
        //            changeRequest?.photoURL = fileUrl
        //            changeRequest?.commitChanges { (error) in
        //
        //                self.removeSpinner()
        //                self.updateProfileImageInDB(url: url ?? "")
        //            }
        //        }
    }
}

extension ProfileVC : UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[.originalImage] as? UIImage
        
        if let image = image {
            
            self.imgView.image = image
            self.selectedImage = image
        }
        
        self.uploadProfileImage()
        picker.dismiss(animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
}
