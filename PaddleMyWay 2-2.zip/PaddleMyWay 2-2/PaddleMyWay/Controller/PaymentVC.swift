//
//  PaymentVC.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 29/03/2023.
//

import UIKit
import Stripe

class PaymentVC: UIViewController {
    
    @IBOutlet var cardTextField: STPPaymentCardTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cardTextField.postalCodeEntryEnabled = false
        self.navigationItem.title = "Payment"
    }
    
    @IBAction func payBtn(_ sender: Any) {
        
        let params = STPCardParams()
        params.number = cardTextField.cardNumber
        params.expMonth = UInt(cardTextField.expirationMonth)
        params.expYear = UInt(cardTextField.expirationYear)
        params.cvc = cardTextField.cvc
        
        if STPCardValidator.validationState(forCard: params) == .valid {
            
            self.showSpinner(onView: self.view)
            STPAPIClient.shared.createToken(withCard: params, completion: { token, error in
                
                if error != nil {
                    
                    self.showAlert(msg: error?.localizedDescription ?? "Stripe Error")
                }else {
                    
                    
                }
            })
        }
    }
}
