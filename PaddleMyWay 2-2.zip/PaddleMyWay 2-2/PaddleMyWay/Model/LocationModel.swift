//
//  LocationModel.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 04/02/2023.
//

import Foundation

struct LocationModel {
    
    var pid: String?
    var id: String?
    var name: String?
    var image: String?
    var price: String?
    var description: String?
}
