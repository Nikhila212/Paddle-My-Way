//
//  PeopleModel.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 08/02/2023.
//

import Foundation

struct PeopleModel {
    
    var id: String?
    var name: String?
}
