//
//  Database.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 18/09/2022.
//

import Foundation
import FirebaseCore
import FirebaseDatabase

var navController = UINavigationController()

class FirebaseTables: NSObject {

    static var User: DatabaseReference {
        return Database.database().reference().child("users")
    }
    
    static var Foods: DatabaseReference {
        return Database.database().reference().child("foods")
    }
    
    static var Drinks: DatabaseReference {
        return Database.database().reference().child("drinks")
    }
    
    static var FoodCategories: DatabaseReference {
        return Database.database().reference().child("foodCategories")
    }
    
    static var DrinkCategories: DatabaseReference {
        return Database.database().reference().child("drinkCategories")
    }
    
    static var SpecialCategories: DatabaseReference {
        return Database.database().reference().child("specialCategories")
    }
    
    static var Orders: DatabaseReference {
        return Database.database().reference().child("orders")
    }
}
