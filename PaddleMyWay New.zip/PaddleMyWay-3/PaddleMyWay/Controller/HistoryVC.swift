//
//  HistoryVC.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 01/04/2023.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import FirebaseCore

class HistoryVC: UIViewController {

    @IBOutlet weak var dataTV: UITableView!
    
    @IBOutlet weak var noRecordLbl: UILabel!
    
    var history: [NSDictionary] = []
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.dataTV.delegate = self
        self.dataTV.dataSource = self
        self.navigationItem.title = "Bookings"
        self.getHistory()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.isHidden = false
    }
    
    func getHistory() -> Void {
        
        let id = Auth.auth().currentUser?.uid ?? ""
        FirebaseTables.History.child(id).observe(.value) { snapshot in
            
            self.history.removeAll()
            for child in snapshot.children {
                
                let snap = child as! DataSnapshot
                let dic = snap.value as? NSDictionary ?? NSDictionary()
                
                self.history.append(dic)
                
            }
            self.dataTV.reloadData()
        }
    }
    
    func moveToSummary(index: Int) -> Void {
        
        let a = self.history[index]
        let str = a["places"] as? String ?? ""
        let arr = str.toJSON() as? NSArray ?? NSArray()
        
        
        var places: [FavPlaces] = []
        for i in 0..<arr.count {
            
            let a = arr[i] as? NSDictionary ?? NSDictionary()
            let place = FavPlaces(context: context)
            place.id = a["id"] as? String ?? ""
            place.image = a["image"] as? String ?? ""
            place.desc = a["desc"] as? String ?? ""
            place.pid = a["pid"] as? String ?? ""
            place.price = a["price"] as? String ?? ""
            
            places.append(place)
        }
        
        let v = self.storyboard?.instantiateViewController(withIdentifier: "TourSummaryVC") as! TourSummaryVC
        
        v.peoples = a["peoples"] as? Int ?? 1
        v.places = places
        v.fromView = "history"
        
        self.navigationController!.pushViewController(v, animated: true)
    }
}

extension HistoryVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return history.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = Bundle.main.loadNibNamed("HistoryTVC", owner: self, options: nil)?.first as! HistoryTVC
        
        let h = history[indexPath.row]
        cell.idLbl.text = String(format: "%@", h["oid"] as? String ?? "13213")
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.moveToSummary(index: indexPath.row)
    }
}
