//
//  TourSummaryVC.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 31/03/2023.
//

import UIKit
import SDWebImage

class TourSummaryVC: UIViewController {
    
    @IBOutlet weak var dataTV: UITableView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet var dateView: UIView!
    @IBOutlet var dateLbl: UILabel!
    
    @IBOutlet var payBtn: UIButton!
    var places: [FavPlaces] = []
    var peoples: Int = 1
    var price = 0.0
    var selectedDate = Date()
    
    var fromView = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Tour Summary"
        self.tabBarController?.tabBar.isHidden = true
        
        self.dataTV.delegate = self
        self.dataTV.dataSource = self
        
        self.calculateCost()
        self.bottomView.layer.cornerRadius = 16
        self.bottomView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        if fromView == "history" {
            
            dateView.isHidden = true
            payBtn.isHidden = true
        }else {
            
            let formatter = DateFormatter()
            formatter.dateFormat = "MMM dd, yyyy"
            let str = formatter.string(from: selectedDate)
            dateLbl.text = str
        }
    }
    
    func calculateCost() -> Void {
        
        
        for loc in places {
            
            let str = loc.price ?? "0.0"
            let p = Double(str) ?? 0.0
            price += p
        }
        
        let total = Double(peoples) * price
        priceLbl.text = String(format: "%0.2f%@", total, Constants.PriceUnit)
        
    }
    
    @IBAction func paymentBtn(_ sender: Any) {
        
        let v = self.storyboard?.instantiateViewController(withIdentifier: "PaymentVC") as! PaymentVC
        
        v.places = self.places
        v.peoples = self.peoples
        v.total = self.price
        v.selectedDate = self.selectedDate
        
        self.navigationController!.pushViewController(v, animated: true)
    }
}

extension TourSummaryVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return places.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = Bundle.main.loadNibNamed("SummaryTVC", owner: self, options: nil)?.first as! SummaryTVC
        
        cell.imgView.layer.cornerRadius = 30
        cell.imgView.clipsToBounds = true
        
        let location = places[indexPath.row]
        
        let url_str = location.image ?? ""
        let url = URL(string: url_str)
        cell.imgView?.sd_setImage(with: url, placeholderImage: UIImage(named: ""),options: SDWebImageOptions(rawValue: 0), completed: { (image, error, cacheType, imageURL) in
        })
        
        cell.nameLbl.text = location.name ?? ""
        cell.peoplesLbl.text = String(format: "%d x %@%@", peoples, location.price ?? "0.0", Constants.PriceUnit)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 82
    }
}
