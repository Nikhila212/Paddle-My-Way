//
//  PaymentVC.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 29/03/2023.
//

import UIKit
import Stripe
import FirebaseAuth
import FirebaseDatabase

class PaymentVC: UIViewController {
    
    @IBOutlet var cardTextField: STPPaymentCardTextField!
    
    var places: [FavPlaces] = []
    var peoples: Int = 1
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var total: Double = 0.0
    var selectedDate = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cardTextField.postalCodeEntryEnabled = false
        self.navigationItem.title = "Payment"
    }
    
    @IBAction func payBtn(_ sender: Any) {
        
        let params = STPCardParams()
        params.number = cardTextField.cardNumber
        params.expMonth = UInt(cardTextField.expirationMonth)
        params.expYear = UInt(cardTextField.expirationYear)
        params.cvc = cardTextField.cvc
        
        self.showSpinner(onView: self.view)
        if STPCardValidator.validationState(forCard: params) == .valid {
            STPAPIClient.shared.createToken(withCard: params, completion: { token, error in
                
                self.removeSpinner()
                if error != nil {
                    
                    self.showAlert(msg: error?.localizedDescription ?? "Stripe Error")
                }else {
                    
                    self.saveHistory()
                }
            })
        }else {
            
            self.removeSpinner()
            self.showAlert(msg: "Invalid card details")
        }
    }
    
    func saveHistory() -> Void {
        
        var history: [NSDictionary] = []
        for place in places {
            
            let p = ["id": place.id ?? "",
                     "pid": place.pid ?? "",
                     "name": place.name ?? "",
                     "price": place.price ?? "0.0",
                     "desc": place.desc ?? "",
                     "image": place.image ?? ""] as! NSDictionary
            
            history.append(p)
        }
        
        let str = self.convertArrayToJson(arr: history)
        
        let random = Int.random(in: 1..<999999)
        let someDate = Date()
        let myTimeStamp = someDate.timeIntervalSince1970
        let a = Int(myTimeStamp)
        
        let oid = String(format: "%d%d", random, a)
        let uid = Auth.auth().currentUser?.uid ?? ""
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-dd-MM HH:mm"
        let date_str = formatter.string(from: selectedDate)
        
        let params = ["oid": oid,
                      "places": str,
                      "peoples": peoples,
                      "amount": total,
                      "date": date_str] as [String : Any]
        
        let childID = String(format: "%d", oid)
        self.showSpinner(onView: self.view)
        FirebaseTables.History.child(uid).child(childID).setValue(params){
            (error:Error?, ref:DatabaseReference) in
            if error == nil {
                
                self.removeSpinner()
                self.deleteFromLocalDB()
                self.saved()
                
            } else {
                
                self.removeSpinner()
                self.showAlert(msg: "Error in saving user")
            }
        }
    }
    
    func saved() -> Void {
        
        let alert = UIAlertController(title: "Success", message: "Booking saved successfully!", preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { _ in
            
            let obj = self.storyboard?.instantiateViewController(withIdentifier: "DestinationsVC") as! DestinationsVC
            self.navigationController!.pushViewController(obj, animated: true)
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    func deleteFromLocalDB() -> Void {
        
        for place in places {
            
            self.context.delete(place)
        }
        
        do {
            try context.save()
        } catch {
            print(error.localizedDescription)
        }
    }
}


extension UIViewController {
    
    func convertArrayToJson(arr: [Any]) -> String {
        
        do {
            let jsonData: Data = try JSONSerialization.data(withJSONObject: arr, options: [])
            if  let jsonString = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue) {
                return jsonString as String
            }
            
        } catch let error as NSError {
            print("Array convertIntoJSON - \(error.description)")
        }
        
        
        return ""
    }
}

extension String {
    func toJSON() -> Any? {
        guard let data = self.data(using: .utf8, allowLossyConversion: false) else { return nil }
        return try? JSONSerialization.jsonObject(with: data, options: .mutableContainers)
    }
}
