//
//  PlaceDetailsVC.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 30/03/2023.
//

import UIKit
import SDWebImage
import CoreData

class PlaceDetailsVC: UIViewController {

    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet weak var descriptionLbl: UILabel!
    
    @IBOutlet weak var favBtn: UIButton!
    
    var SavedPlace: FavPlaces?
    
    var loc: LocationModel?
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = loc?.name ?? ""
        self.showData()
        self.checkIsWishList()
    }
    
    func showData() -> Void {
        
        let url_str = loc?.image ?? ""
        let url = URL(string: url_str)
        imgView?.sd_setImage(with: url, placeholderImage: UIImage(named: ""),options: SDWebImageOptions(rawValue: 0), completed: { (image, error, cacheType, imageURL) in
        })
        
        nameLbl.text = loc?.name ?? ""
        priceLbl.text = String(format: "%@%@", loc?.price ?? 0, Constants.PriceUnit)
        descriptionLbl.text = loc?.description ?? ""
    }
    
    @IBAction func AddBtn(_ sender: Any) {
        
        if let place = SavedPlace {
            
            self.context.delete(place)
            SavedPlace = nil
            
        } else {
            let place = FavPlaces(context: self.context)
            if let placeInfo = loc {
                
                place.pid = placeInfo.pid
                place.id = placeInfo.id
                place.name = placeInfo.name
                place.image = placeInfo.image
                place.desc = placeInfo.description
                place.price = placeInfo.price
            }
            SavedPlace = place
        }
        
        do {
            try context.save()
        } catch {
            print(error.localizedDescription)
        }
        
        self.checkIsWishList()
    }
    
    func checkIsWishList() -> Void {
        
        do {
            let wishList: [FavPlaces] = try context.fetch(FavPlaces.fetchRequest())
            
            for place in wishList {
                if place.id == loc?.id && place.pid == loc?.pid {
                    SavedPlace = place
                }
            }
        } catch {
            print(error.localizedDescription)
        }
        
        let symbol: String = SavedPlace != nil ? "1" : "2"
        if symbol == "1" {
            
            favBtn.setTitle("Remove From Wishlist", for: .normal)
        }else{
            
            favBtn.setTitle("Add To Wishlist", for: .normal)
        }
    }
}
