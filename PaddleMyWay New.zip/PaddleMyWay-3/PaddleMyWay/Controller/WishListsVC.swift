//
//  WishListsVC.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 30/03/2023.
//

import UIKit
import SDWebImage

class WishListsVC: UIViewController {
    
    
    @IBOutlet weak var noRecordLbl: UILabel!
    @IBOutlet weak var dataTV: UITableView!
    
    @IBOutlet weak var qtyView: UIView!
    @IBOutlet weak var qtyLbl: UILabel!
    @IBOutlet weak var bottomView: UIView!
    
    @IBOutlet var dateBtn: UIButton!
    
    @IBOutlet var dateView: UIView!
    @IBOutlet var datePicker: UIDatePicker!
    
    var selectedDate: Date? = nil
    var selectedPlaces: [Int] = []
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var placesLists: [FavPlaces] = []
    var total = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.bottomView.isHidden = true
        self.dataTV.delegate = self
        self.dataTV.dataSource = self
        
        self.qtyView.layer.cornerRadius = self.qtyView.frame.standardized.height / 2
        self.bottomView.layer.cornerRadius = 16
        self.bottomView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        self.dateView.layer.cornerRadius = 16
        self.dateView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        self.dateView.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tabBarController?.tabBar.isHidden = false
        self.getWishList()
    }
    
    //MARK: Tickets Movies
    func getWishList() -> Void {
        
        do {
            placesLists = try context.fetch(FavPlaces.fetchRequest())
            if placesLists.count > 0 {
                
                self.noRecordLbl.isHidden = true
                self.dataTV.isHidden = false
                
            }else{
                
                self.noRecordLbl.isHidden = false
                self.dataTV.isHidden = true
            }
            
            self.dataTV.reloadData()
        } catch {
            
            print(error.localizedDescription)
        }
        
        self.bottomView.isHidden = true
        if selectedPlaces.count > 0 {
            
            self.bottomView.isHidden = false
        }
        
    }
    
    @IBAction func minusBtn(_ sender: Any) {
        
        if total > 1 {
            
            total -= 1
        }
        
        qtyLbl.text = String(format: "%d", total)
    }
    
    @IBAction func plusBtn(_ sender: Any) {
        
        total += 1
        qtyLbl.text = String(format: "%d", total)
    }
    
    
    @IBAction func cartBtn(_ sender: Any) {
        
        if selectedDate == nil {
            
            self.showAlert(msg: "Please select date")
            return
        }
        
        var selectedLocations: [FavPlaces] = []
        for i in 0..<selectedPlaces.count {
            
            let index = selectedPlaces[i]
            selectedLocations.append(placesLists[index])
        }
        
        
        let v = self.storyboard?.instantiateViewController(withIdentifier: "TourSummaryVC") as! TourSummaryVC
        
        v.selectedDate = selectedDate ?? Date()
        v.peoples = total
        v.places = selectedLocations
        
        self.navigationController!.pushViewController(v, animated: true)
    }
    
    @objc func statusBtnClicked(sender: UIButton) -> Void {
        
        let index = sender.tag
        if selectedPlaces.contains(index) {
            
            selectedPlaces = selectedPlaces.filter { $0 != index }
        }else {
            
            selectedPlaces.append(index)
        }
        
        self.bottomView.isHidden = true
        if selectedPlaces.count > 0 {
            
            self.bottomView.isHidden = false
        }
        
        self.dataTV.reloadData()
    }
    
    @objc func favBtnClicked(sender: UIButton) -> Void {
        
        let index = sender.tag
        let place = placesLists[index]
        
        self.context.delete(place)
        do {
            
            selectedPlaces = selectedPlaces.filter { $0 != index }
            
            try context.save()
        } catch {
            print(error.localizedDescription)
        }
        
        self.getWishList()
    }
    
    @IBAction func selectDateBtnClicked(_ sender: Any) {
        
        datePicker.date = selectedDate ?? Date()
        dateView.isHidden = false
        datePicker.minimumDate = Date()
    }
    
    @IBAction func cancelBtnClicked(_ sender: Any) {
        
        dateView.isHidden = true
    }
    
    @IBAction func doneBtnClicked(_ sender: Any) {
        
        dateView.isHidden = true
        selectedDate = datePicker.date
        
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd, yyyy"
        let str = formatter.string(from: selectedDate!)
        dateBtn.setTitle(str, for: .normal)
    }
}

extension WishListsVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return placesLists.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = Bundle.main.loadNibNamed("WishlistTVC", owner: self, options: nil)?.first as! WishlistTVC
        
        cell.imgView.layer.cornerRadius = 30
        cell.imgView.clipsToBounds = true
        
        let location = placesLists[indexPath.row]
        
        let url_str = location.image ?? ""
        let url = URL(string: url_str)
        cell.imgView?.sd_setImage(with: url, placeholderImage: UIImage(named: ""),options: SDWebImageOptions(rawValue: 0), completed: { (image, error, cacheType, imageURL) in
        })
        
        cell.nameLbl.text = location.name ?? ""
        
        cell.favBtn.tag = indexPath.row
        cell.favBtn.addTarget(self, action: #selector(self.favBtnClicked(sender:)), for: .touchUpInside)
        
        cell.statusBtn.tag = indexPath.row
        cell.statusBtn.addTarget(self, action: #selector(self.statusBtnClicked(sender:)), for: .touchUpInside)
        
        cell.statusBtn.setImage(UIImage(named: "BoxUnChecked"), for: .normal)
        cell.statusBtn.tintColor = UIColor.lightGray
        
        let ThemeColor = UIColor(named: "ThemeColor")
        if selectedPlaces.contains(indexPath.row) {
            
            cell.statusBtn.setImage(UIImage(named: "BoxChecked"), for: .normal)
            cell.statusBtn.tintColor = ThemeColor
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 82
    }
}
