//
//  DestinationCVC.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 22/09/2022.
//

import UIKit

class DestinationCVC: UICollectionViewCell {
    
    @IBOutlet var contantView: UIView!
    @IBOutlet var imgView: UIImageView!
    
    @IBOutlet var bgView: UIView!
    @IBOutlet var nameLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
