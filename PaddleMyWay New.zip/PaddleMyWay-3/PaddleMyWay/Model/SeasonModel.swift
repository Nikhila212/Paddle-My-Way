//
//  SeasonModel.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 08/02/2023.
//

import Foundation

struct SeasonModel {
    
    var id: String?
    var name: String?
}
