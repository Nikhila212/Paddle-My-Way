//
//  DestinationModel.swift
//  PaddleMyWay
//
//  Created by Patmavathi on 03/02/2023.
//

import Foundation

struct DestinationModel {
    
    var id: String?
    var name: String?
    var image: String?
    
    var peoples: String?
    var seasons: String?
    
}
